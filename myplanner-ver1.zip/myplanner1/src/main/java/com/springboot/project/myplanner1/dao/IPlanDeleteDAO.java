package com.springboot.project.myplanner1.dao;

import com.springboot.project.myplanner1.dto.PlanDeleteDTO;

public interface IPlanDeleteDAO {
	public void planDelete(PlanDeleteDTO planDeleteDto);
}
