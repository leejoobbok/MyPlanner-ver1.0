package com.springboot.project.myplanner1.dao;

import com.springboot.project.myplanner1.dto.PlanInsertDTO;

public interface IPlanInsertDAO {
	public void planInsert(PlanInsertDTO planInsertDto);
}
