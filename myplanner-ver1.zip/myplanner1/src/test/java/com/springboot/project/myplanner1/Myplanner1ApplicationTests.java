package com.springboot.project.myplanner1;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myplanner1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
